package com.example.testtest

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
