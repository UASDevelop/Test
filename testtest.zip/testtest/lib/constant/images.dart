class AppImages {
  static const String mainImage = "assets/images/";
  static const String home = "${mainImage}home.png";
  static const String search = "${mainImage}search.png";
  static const String create = "${mainImage}create.png";

  static const String chat = "${mainImage}chat.png";
  static const String profile = "${mainImage}profle1.png";
  static const String gallery="${mainImage}image.png";
  static const String camera="${mainImage}camera.png";
  static const String settinng="${mainImage}setting.png";
  static const String chance="${mainImage}chance.png";
  static const String verify="${mainImage}verify.png";
  static const String notificaitonn="${mainImage}notification.png";
}
