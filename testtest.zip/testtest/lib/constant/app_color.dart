import 'dart:ui';

class AppColor{
  static const Color blackcolor=Color(0xff141414);
  static const Color secondaryblude=Color(0xff364960);
  static const Color primarygreen=Color(0xff5DC482);
  
}